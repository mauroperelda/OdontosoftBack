using OdontoSoft.Data.Repository.UOW;
using OdontoSoft.Entities.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace OdontoSoft.Web.Controllers
{
    public partial class PresupuestoController : AppBaseBrowserController
    {
        private Dictionary<string, object> PrepareViewBag(Presupuesto entity)
        {
            Dictionary<string, object> viewBagData = new Dictionary<string, object>();
            SelectList pacienteList = new SelectList(_unitOfWork.PacienteRepository.GetAllEnabled(entity.PacienteId).ToList(), "Id", "GetString", entity.PacienteId);
            viewBagData.Add("paciente", pacienteList);
            SelectList profesionalList = new SelectList(_unitOfWork.ProfesionalRepository.GetAllEnabled(entity.ProfesionalId).ToList(), "Id", "GetString", entity.ProfesionalId);
            viewBagData.Add("profesional", profesionalList);
            return viewBagData;
        }

        private void PrepareEntityFromFormData(Presupuesto entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to update the entity from specific data in formCollection.
        }

        private void PrepareEntityBeforeLoadForm(Presupuesto entity)
        {
            //Implement here any functionallity to update the entity before EditForm shows.
        }

        private void ActionsBeforeSave(Presupuesto entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to execute any action before unitofworks.Save
        }

        private void ActionsAfterSave(Presupuesto entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to execute any action after unitofworks.Save
        }
    }
}

