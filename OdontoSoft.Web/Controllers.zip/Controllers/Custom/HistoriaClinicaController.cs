using OdontoSoft.Data.Repository.UOW;
using OdontoSoft.Entities.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace OdontoSoft.Web.Controllers
{
    public partial class HistoriaClinicaController : AppBaseBrowserController
    {
        private Dictionary<string, object> PrepareViewBag(HistoriaClinica entity)
        {
            Dictionary<string, object> viewBagData = new Dictionary<string, object>();
            SelectList pacienteList = new SelectList(_unitOfWork.PacienteRepository.GetAllEnabled(entity.PacienteId).ToList(), "Id", "GetString", entity.PacienteId);
            viewBagData.Add("paciente", pacienteList);
            return viewBagData;
        }

        private void PrepareEntityFromFormData(HistoriaClinica entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to update the entity from specific data in formCollection.
        }

        private void PrepareEntityBeforeLoadForm(HistoriaClinica entity)
        {
            //Implement here any functionallity to update the entity before EditForm shows.
        }

        private void ActionsBeforeSave(HistoriaClinica entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to execute any action before unitofworks.Save
        }

        private void ActionsAfterSave(HistoriaClinica entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to execute any action after unitofworks.Save
        }
    }
}

