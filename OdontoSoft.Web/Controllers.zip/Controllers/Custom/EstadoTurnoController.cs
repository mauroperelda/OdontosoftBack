using OdontoSoft.Data.Repository.UOW;
using OdontoSoft.Entities.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace OdontoSoft.Web.Controllers
{
    public partial class EstadoTurnoController : AppBaseBrowserController
    {
        private Dictionary<string, object> PrepareViewBag(EstadoTurno entity)
        {
            Dictionary<string, object> viewBagData = new Dictionary<string, object>();
            return viewBagData;
        }

        private void PrepareEntityFromFormData(EstadoTurno entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to update the entity from specific data in formCollection.
        }

        private void PrepareEntityBeforeLoadForm(EstadoTurno entity)
        {
            //Implement here any functionallity to update the entity before EditForm shows.
        }

        private void ActionsBeforeSave(EstadoTurno entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to execute any action before unitofworks.Save
        }

        private void ActionsAfterSave(EstadoTurno entity, Microsoft.AspNetCore.Http.IFormCollection formCollection)
        {
            //Implement here any functionallity to execute any action after unitofworks.Save
        }
    }
}

